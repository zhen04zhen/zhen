package com.example.b11109023_hw2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.example.b11109023_hw2.ui.theme.MyComposeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyComposeAppTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "home") {
                    composable("home") { HomeScreen(navController) }
                    composable(
                        "details/{destinationName}/{imageResId}/{description}/{extraInfo}",
                        arguments = listOf(
                            navArgument("destinationName") { type = NavType.StringType },
                            navArgument("imageResId") { type = NavType.IntType },
                            navArgument("description") { type = NavType.StringType },
                            navArgument("extraInfo") { type = NavType.StringType }
                        )
                    ) { backStackEntry ->
                        val destinationName = backStackEntry.arguments?.getString("destinationName") ?: ""
                        val imageResId = backStackEntry.arguments?.getInt("imageResId") ?: 0
                        val description = backStackEntry.arguments?.getString("description") ?: ""
                        val extraInfo = backStackEntry.arguments?.getString("extraInfo") ?: ""
                        DetailsScreen(navController, destinationName, imageResId, description, extraInfo)
                    }
                }
            }
        }
    }
}

//data
data class TravelDestination(val imageResId: Int, val name: String, val description: String, val extraInfo: String)

val sampleDestinations = listOf(
    TravelDestination(R.drawable.i1, "松山療養所所長宿舍", "沿著車水馬龍的南港昆陽街拐進一條僻靜的巷弄，躲藏在此處已百年的日式老建築「松山療養所所長宿舍」，突如其來的映入眼簾。\n" +
            "庭院前的人力車、六角窗、八角柱、敞開的日式拉門與長廊，無處不彰顯著這裡的漫長歲月，這是一個會讓人想緩下腳步、靜下心，享受放空也無妨的靜謐空間，現在由「靜心苑」經營為餐廳，提供台日融合料理，一起來體驗緩慢生活吧！","▶\uFE0E地址：115台北市南港區昆陽街164號\n▶\uFE0E營業時間：11:00-19:00（週二公休）\n" +
            "▶\uFE0E詳細資訊：松山療養所所長宿舍FB"),
    TravelDestination(R.drawable.i2, "台北101", "身為台北最重要的地標，當然要前去拍照打卡一下啦～台北101內的地下1樓至4樓為購物中心，有名的小籠包餐廳鼎泰豐也位於此。另外，搭乘快速恆壓電梯至89樓的觀景台，從高處一覽整個台北市也是個不錯的體驗唷！","▶\uFE0E地址：台北市信義區市府路45號\n▶︎詳細資訊：台北101官網"),
    TravelDestination(R.drawable.i3, "西門紅樓", "西門町是台北著名的逛街地點，流行服飾、美妝都可以在這裡大採購一番。西門町也是台北著名的電影街，許多電影院在此林立。另外，西門紅樓更是許多喜歡文創朋友們的天堂，每週六日還有市集可以逛逛喲！\n","▶\uFE0E地址：108台北市萬華區成都路10號\n▶\uFE0E詳細資訊：西門紅樓官網"),
    TravelDestination(R.drawable.img4, "國立故宮博物院", "國立故宮博物院是世界典藏最多寶物的博物館之一，典藏許多宮廷文物、藝術品等，例如翠玉白菜、肉形石都是裡面著名的珍藏品。故宮不只可以參觀，位於其左側的至善園，以王羲之的八大勝景為構思，很適合在逛完展覽後，以悠閒的步調漫步在書香氣息當中。","▶\uFE0E地址：111台北市士林區至善路二段221號\n▶\uFE0E詳細資訊：故宮博物院官網"),
    TravelDestination(R.drawable.img5, "瓶蓋工廠", "「瓶蓋工廠」的起源為日治時期的國產軟木工業株式會社，二戰後更改為臺灣菸酒公賣局瓶蓋工廠，於2004年正式熄燈，而2018年經過整修後，以手創、文青的展場樣貌再次重新開放！\n" +
            "瓶蓋工廠就在南港車站旁，園區的戶外廣場有一面瓶蓋印象造景牆，拍照起來很亮眼，這裡有時也會舉辦假日市集、現場live表演，發展非常多元呢！","▶\uFE0E地址：115台北市南港區南港路二段13號\n▶\uFE0E營業時間：10:00-18:00\n▶\uFE0E詳細資訊：瓶蓋工廠官網"),
    TravelDestination(R.drawable.img6, "政治大學達賢圖書館", "被稱為最美圖書館的政治大學達賢圖書館，是座落在木柵動物園附近的隱藏打卡景點，挑高七層樓的書牆設計吸引許多攝影好手前往駐足，完全不輸韓國的星空圖書館！達賢圖書館也有提供地下停車場，開車前往也很方便喔。\n" +
            "小編十分推薦與台北動物園、貓空纜車安排成一日遊行程，而且只要步行10分鐘就可以抵達政大商圈，各種大學生最愛的高CP值美食餐廳四處林立，隨便走進一家都可以好好飽足一頓呢。","▶\uFE0E地址：116台北市文山區萬壽路36號\n▶\uFE0E營業時間：08:00-21:45，週日不開放\n▶\uFE0E詳細資訊：政治大學達賢圖書館官網"),
    TravelDestination(R.drawable.img7, "寶藏巖國際藝術村", "「寶藏巖國際藝術村」一個隱匿在公館附近，於民國60-70年依山而建的眷村小社區，從2010年開始有設計師進駐在此開設工作室，也使這裡添增不少彩繪牆面、裝置藝術及文青擺設，而這個台北秘境僅需從捷運公館站1號出口步行約10分鐘即可抵達，很適合親子一起輕鬆爬個小山、在錯落有序的小山坡開啟尋寶旅途喔！","▶\uFE0E地址：100台北市中正區汀州路三段230巷14弄2號\n▶\uFE0E營業時間：24H\n" +
            "▶\uFE0E詳細資訊：寶藏巖國際藝術村FB"),
    TravelDestination(R.drawable.img8, "自來水博物館", "「自來水博物館」堪稱台北最物超所值的親子玩水景點！門票百元有找、12歲以下半價、6歲以下免費，在此除了可以學習到抽水機組設備等相關知識以外，最令孩子們期待的就是夏天開放的玩水派對啦！有滑水道及花式灑水設施，且泳池水深僅到大人膝蓋，一旁還有救生員待命，安全感大幅提升呀，推薦此等夏天好去處給親子爸媽們唷！","▶\uFE0E地址：100台北市中正區思源街1號\n▶\uFE0E營業時間：9:09-17:00（週一公休）\n" +
            "▶\uFE0E詳細資訊：自來水園區FB"),
    TravelDestination(R.drawable.img9, "陽明山", "陽明山真的是踏青郊遊的好去處，不只可以看到如小油坑、大磺嘴等特殊的火山地質，由於海拔與緯度的關係，四季皆可欣賞不同種類的花。另外，陽明山的夜景也是情侶們約會的熱門景點。\n" +
            "2 – 3月的櫻花季\n" +
            "3 – 4月的竹子湖海芋季\n" +
            "5月中旬的繡球花季\n" +
            "10月 – 隔年1月的賞楓季","▶\uFE0E地址：台北市北投區竹子湖路1-20號\n▶\uFE0E詳細資訊：陽明山國家公園官網"),
    TravelDestination(R.drawable.img10, "地熱谷", "北投溫泉源頭之一的「地熱谷」，這裡終年瀰漫著硫磺煙霧，輕煙裊裊仿佛戴著一層神秘面紗，而這麼夢幻的景點距離新北投站僅15分鐘，還可以延著環湖步道近距離欣賞美景，是不是很值得一去？\n" +
            "另外地熱谷有一種含有放射性元素鐳的稀有「北投石」，據說有養顏美容等功效，因此可別錯過在進園前的「淨手礦泉湯」讓雙手潤膚一下囉！","▶\uFE0E地址：112台北市北投區中山路30號之10\n▶\uFE0E營業時間：9:00-17:00（週一公休）\n" +
            "▶\uFE0E詳細資訊：臺北北投區公所官網"),
    TravelDestination(R.drawable.img11, "大稻埕", "「大稻埕」一直都是台北旅遊人氣地點呢！18世紀末因淡水港的開放，大稻埕一躍為繁華的商貿中心。而現如今大稻埕逛碼頭市集、霞海城隍廟拜月老、迪化街掃年貨等，可都是台北一日遊必訪行程！近年來也進駐了許多手創文物店、文青咖啡廳與老宅改建的特色餐廳等，無論是觀光散策、還是在碼頭看煙火，都充滿懷舊浪漫呢！","▶\uFE0E地址：103台北市大同區民生西路底五號水門, 大稻埕碼頭\n▶\uFE0E營業時間：24H\n" +
            "▶\uFE0E詳細資訊：台灣交通部觀光署官網"),
    TravelDestination(R.drawable.img12, "九份老街", "極具魅力的山城小鎮—九份，坡上獨特風味的舊式建築，在電影「悲情城市」的取景下，吸引許多影迷前往。再加上九份的茶樓激似宮崎駿電影「神隱少女」的場景，近年來更是吸引許多日本遊客前來朝聖。","▶\uFE0E地址：新北市瑞芳區基山街"),

    )

//主頁
@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Header()
        TravelDestinationsList(destinations = sampleDestinations, navController)
    }
}

//第二頁
@Composable
fun DetailsScreen(navController: NavHostController, name: String, imageResId: Int, description: String, extraInfo: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.background),
                    startY = 0f,
                    endY = 1000f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()), // 使用垂直滚动修饰符
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(onClick = { navController.popBackStack() }, modifier = Modifier.align(Alignment.Start)) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Image(
                painter = painterResource(id = imageResId),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(300.dp) // 增加图片大小
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(bottom = 8.dp),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 18.sp,
                            lineHeight = 24.sp
                        ),
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = extraInfo,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 18.sp,
                            lineHeight = 24.sp
                        ),
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    val gmmIntentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$name")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    mapIntent.setPackage("com.google.android.apps.maps")
                    navController.context.startActivity(mapIntent)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(text = "在 Google Maps 中打開", color = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

//景點列表
@Composable
fun TravelDestinationsList(destinations: List<TravelDestination>, navController: NavHostController) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        items(destinations) { destination ->
            TravelDestinationItem(destination, navController)
        }
    }
}

//項目
@Composable
fun TravelDestinationItem(destination: TravelDestination, navController: NavHostController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable {
                navController.navigate(
                    "details/${destination.name}/${destination.imageResId}/${destination.description}/${destination.extraInfo}"
                )
            },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .padding(16.dp)
        ) {
            Image(
                painter = painterResource(id = destination.imageResId),
                contentDescription = destination.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(128.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .padding(end = 16.dp)
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = destination.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    text = destination.description,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 16.sp),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}


@Composable
fun Header() {
    Text(
        text = "北區旅遊景點推薦",
        style = MaterialTheme.typography.headlineLarge,
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        textAlign = TextAlign.Center
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    MyComposeAppTheme {
        val navController = rememberNavController()
        HomeScreen(navController)
    }
}
