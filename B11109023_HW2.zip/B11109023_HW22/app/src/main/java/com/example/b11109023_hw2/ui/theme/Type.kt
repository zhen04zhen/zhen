package com.example.b11109023_hw2.ui.theme

import androidx.compose.material3.Typography

// Set of Material typography styles to start with
val Typography = Typography(
    // Customize your typography here
    // Example:
    // body1 = TextStyle(
    //     fontFamily = FontFamily.Default,
    //     fontWeight = FontWeight.Normal,
    //     fontSize = 16.sp
    // )
)
